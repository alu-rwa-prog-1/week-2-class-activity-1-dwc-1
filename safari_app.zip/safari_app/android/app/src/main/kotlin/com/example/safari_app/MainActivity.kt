package com.example.safari_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
